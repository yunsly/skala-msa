<template>
  <div class="page-wrapper">
    <AppHeader />
    <div class="detail-layout" v-if="course">
      <!-- 헤더 -->
      <div class="detail-hero">
        <div class="detail-hero-inner">
          <div class="detail-info fade-in-up">
            <span class="badge" :class="badgeClass">{{ course.category }}</span>
            <h1 class="detail-title">{{ course.title }}</h1>
            <p class="detail-desc">{{ course.description || '실무 전문가가 직접 설계한 커리큘럼으로 체계적으로 학습하세요.' }}</p>
            <div class="detail-meta">
              <span>강사: {{ course.instructorName }}</span>
              <span>수강생: {{ course.enrollmentCount?.toLocaleString() }}명</span>
            </div>
          </div>
          <!-- 수강 신청 카드 -->
          <div class="enroll-card fade-in">
            <div class="enroll-thumb" :class="thumbBg">
              <img v-if="thumbSrc" :src="thumbSrc" :alt="course.title" />
            </div>
            <div class="enroll-body">
              <div class="enroll-price">₩{{ Number(course.price).toLocaleString() }}</div>
              <button class="btn btn-primary btn-full" @click="handleEnroll" :disabled="enrolling || enrolled">
                <span v-if="enrolling">신청 중...</span>
                <span v-else-if="enrolled">수강 중</span>
                <span v-else>수강 신청</span>
              </button>
              <div v-if="enrollError" class="error-msg">{{ enrollError }}</div>
              <ul class="enroll-info-list">
                <li>✅ 즉시 수강 가능</li>
                <li>✅ 평생 소장</li>
                <li>✅ 수료증 발급</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 로딩 -->
    <div v-else-if="loading" class="loading-center">
      <div class="spinner"></div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import { useCourseStore } from '@/store/course.js'
import { enrollmentApi } from '@/api/enrollment.js'

const route = useRoute()
const router = useRouter()
const courseStore = useCourseStore()

const enrolling = ref(false)
const enrolled  = ref(false)
const enrollError = ref('')

const course  = computed(() => courseStore.selectedCourse)
const loading = computed(() => courseStore.loading)

const categoryConfig = {
  '백엔드':    { badge: 'badge-teal',   bg: 'thumb-teal',   thumb: 'spring_boot' },
  '프론트엔드':{ badge: 'badge-teal',   bg: 'thumb-teal',   thumb: 'vue_js' },
  'DevOps':   { badge: 'badge-blue',   bg: 'thumb-blue',   thumb: 'kubernetes' },
  '데이터':   { badge: 'badge-purple', bg: 'thumb-purple', thumb: 'python' },
  'AI':       { badge: 'badge-pink',   bg: 'thumb-pink',   thumb: 'generative_ai' },
}
const config    = computed(() => categoryConfig[course.value?.category] || {})
const badgeClass = computed(() => config.value.badge)
const thumbBg   = computed(() => config.value.bg)
const thumbSrc  = computed(() => {
  const key = course.value?.thumbnail || config.value.thumb
  if (!key) return null
  try { return new URL(`../assets/images/courses/${key}.png`, import.meta.url).href }
  catch { return null }
})

async function handleEnroll() {
  enrolling.value = true
  enrollError.value = ''
  try {
    await enrollmentApi.enroll(course.value.id)
    enrolled.value = true
    router.push('/enrollments')
  } catch (e) {
    enrollError.value = e.response?.data?.message || '수강 신청에 실패했습니다.'
  } finally {
    enrolling.value = false
  }
}

onMounted(() => {
  courseStore.fetchCourse(route.params.id)
})
</script>

<style scoped>
.page-wrapper { min-height: 100vh; background: var(--color-bg-secondary); }
.detail-hero {
  background: linear-gradient(135deg, #f0f7ff 0%, #e8f4fd 100%);
  border-bottom: 1px solid var(--color-border);
  padding: 48px 0;
}
.detail-hero-inner {
  max-width: 1100px;
  margin: 0 auto;
  padding: 0 24px;
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 48px;
  align-items: start;
}
.detail-info { display: flex; flex-direction: column; gap: 14px; }
.detail-title { font-size: 30px; font-weight: 700; line-height: 1.3; }
.detail-desc { font-size: 15px; color: var(--color-text-secondary); line-height: 1.7; }
.detail-meta { display: flex; gap: 20px; font-size: 14px; color: var(--color-text-secondary); }

.enroll-card {
  background: var(--color-bg-primary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  overflow: hidden;
  box-shadow: var(--shadow-md);
}
.enroll-thumb {
  height: 160px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.enroll-thumb img { width: 100%; height: 100%; object-fit: contain; padding: 20px; }
.thumb-teal   { background: #E1F5EE; }
.thumb-blue   { background: #E6F1FB; }
.thumb-purple { background: #EEEDFE; }
.thumb-pink   { background: #FBEAF0; }
.enroll-body { padding: 20px; display: flex; flex-direction: column; gap: 14px; }
.enroll-price { font-size: 26px; font-weight: 700; color: var(--color-primary); }
.btn-full { width: 100%; padding: 13px; font-size: 15px; justify-content: center; }
.enroll-info-list { list-style: none; display: flex; flex-direction: column; gap: 8px; }
.enroll-info-list li { font-size: 13px; color: var(--color-text-secondary); }
.error-msg { font-size: 13px; color: #dc2626; padding: 8px 12px; background: #fef2f2; border-radius: var(--radius-sm); }
.loading-center { display: flex; justify-content: center; padding: 100px 0; }
.spinner { width: 40px; height: 40px; border: 3px solid var(--color-border); border-top-color: var(--color-primary); border-radius: 50%; animation: spin 0.8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
</style>
