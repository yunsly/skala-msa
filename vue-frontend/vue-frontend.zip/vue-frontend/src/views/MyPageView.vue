<template>
  <div class="page-wrapper">
    <AppHeader />
    <div class="page-layout">
      <aside class="sidebar">
        <div class="sidebar-section">
          <div class="sidebar-label">메뉴</div>
          <router-link to="/courses"     class="sidebar-item"><span class="si-icon">📚</span> 강의 목록</router-link>
          <router-link to="/enrollments" class="sidebar-item"><span class="si-icon">✅</span> 내 수강 목록</router-link>
          <router-link to="/mypage"      class="sidebar-item active"><span class="si-icon">⭐</span> 마이페이지</router-link>
        </div>
        <div class="sidebar-section">
          <div class="sidebar-label">계정</div>
          <button class="sidebar-item sidebar-btn" @click="handleLogout"><span class="si-icon">🚪</span> 로그아웃</button>
        </div>
      </aside>

      <main class="main-content">
        <!-- 프로필 카드 -->
        <div class="profile-card fade-in-up">
          <div class="profile-avatar">{{ auth.user?.name?.charAt(0) || '?' }}</div>
          <div class="profile-info">
            <h2 class="profile-name">{{ auth.user?.name }}</h2>
            <p class="profile-email">{{ auth.user?.email }}</p>
            <span class="badge" :class="auth.isInstructor ? 'badge-amber' : 'badge-blue'">
              {{ auth.isInstructor ? '강사' : '학생' }}
            </span>
          </div>
        </div>

        <!-- 추천 강의 -->
        <section class="recommend-section">
          <h3 class="section-title">추천 강의</h3>
          <div v-if="recommendLoading" class="loading-row">
            <div v-for="i in 3" :key="i" class="skeleton-card">
              <div class="skeleton-thumb"></div>
              <div class="skeleton-body">
                <div class="skeleton-line short"></div>
                <div class="skeleton-line"></div>
              </div>
            </div>
          </div>
          <div v-else-if="recommendations.length" class="recommend-grid fade-in">
            <CourseCard v-for="c in recommendations" :key="c.id" :course="c" />
          </div>
          <p v-else class="empty-text">추천 강의를 불러오는 중입니다.</p>
        </section>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import CourseCard from '@/components/CourseCard.vue'
import { useAuthStore } from '@/store/auth.js'
import { enrollmentApi } from '@/api/enrollment.js'

const router = useRouter()
const auth = useAuthStore()
const recommendations = ref([])
const recommendLoading = ref(true)

function handleLogout() { auth.logout(); router.push('/') }

onMounted(async () => {
  if (auth.user?.id) {
    try {
      const res = await enrollmentApi.getRecommendations(auth.user.id)
      recommendations.value = res.data
    } catch { /* 추천 없을 수 있음 */ }
    finally { recommendLoading.value = false }
  } else {
    recommendLoading.value = false
  }
})
</script>

<style scoped>
.page-wrapper { min-height: 100vh; background: var(--color-bg-secondary); }
.page-layout { max-width: 1200px; margin: 0 auto; padding: 32px 24px; display: grid; grid-template-columns: 220px 1fr; gap: 28px; }
.sidebar { display: flex; flex-direction: column; gap: 8px; }
.sidebar-section { display: flex; flex-direction: column; gap: 2px; margin-bottom: 8px; }
.sidebar-label { font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.08em; color: var(--color-text-muted); padding: 8px 12px 4px; }
.sidebar-item { display: flex; align-items: center; gap: 10px; padding: 9px 12px; border-radius: var(--radius-md); font-size: 14px; color: var(--color-text-secondary); transition: var(--transition); background: none; border: none; width: 100%; text-align: left; cursor: pointer; font-family: var(--font-sans); }
.sidebar-item:hover { background: var(--color-bg-tertiary); color: var(--color-text-primary); }
.sidebar-item.active { background: var(--color-primary-light); color: var(--color-primary); font-weight: 500; }
.si-icon { font-size: 15px; }
.main-content { min-width: 0; display: flex; flex-direction: column; gap: 32px; }

.profile-card {
  display: flex;
  align-items: center;
  gap: 20px;
  background: var(--color-bg-primary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  padding: 28px;
  box-shadow: var(--shadow-sm);
}
.profile-avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: var(--color-primary-light);
  color: var(--color-primary);
  font-size: 24px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.profile-info { display: flex; flex-direction: column; gap: 4px; }
.profile-name { font-size: 20px; font-weight: 700; }
.profile-email { font-size: 14px; color: var(--color-text-secondary); }

.section-title { font-size: 18px; font-weight: 700; margin-bottom: 16px; }
.recommend-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.loading-row { display: grid; grid-template-columns: repeat(3,1fr); gap: 16px; }
.skeleton-card { background: var(--color-bg-primary); border-radius: var(--radius-lg); overflow: hidden; border: 1px solid var(--color-border); }
.skeleton-thumb { height: 110px; background: linear-gradient(90deg,#f0f0f0 25%,#e0e0e0 50%,#f0f0f0 75%); background-size: 200% 100%; animation: shimmer 1.4s infinite; }
.skeleton-body { padding: 14px 16px; display: flex; flex-direction: column; gap: 8px; }
.skeleton-line { height: 12px; border-radius: 6px; background: linear-gradient(90deg,#f0f0f0 25%,#e0e0e0 50%,#f0f0f0 75%); background-size: 200% 100%; animation: shimmer 1.4s infinite; }
.skeleton-line.short { width: 40%; }
@keyframes shimmer { to { background-position: -200% 0; } }
.empty-text { color: var(--color-text-muted); font-size: 14px; }
</style>
