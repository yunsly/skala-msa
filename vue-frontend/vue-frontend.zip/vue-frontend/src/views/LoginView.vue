<template>
  <div class="login-page">
    <div class="login-layout">
      <!-- 좌측 브랜딩 -->
      <div class="login-left">
        <div class="brand">
          <img src="@/assets/images/logo/main_logo.png" alt="LearnNexus" class="brand-logo" />
          <span class="brand-name">LearnNexus</span>
        </div>
        <div class="brand-content">
          <h2>다시 만나서<br>반갑습니다</h2>
          <p>로그인하고 나만의 학습 여정을 이어가세요.</p>
          <ul class="feature-list">
            <li v-for="f in features" :key="f">
              <span class="dot"></span>{{ f }}
            </li>
          </ul>
        </div>
      </div>

      <!-- 우측 폼 -->
      <div class="login-right">
        <div class="login-box fade-in-up">
          <router-link to="/" class="back-link">← 홈으로</router-link>

          <!-- 탭 -->
          <div class="tabs">
            <button :class="['tab', { active: tab === 'login' }]" @click="tab = 'login'">로그인</button>
            <button :class="['tab', { active: tab === 'register' }]" @click="tab = 'register'">회원가입</button>
          </div>

          <!-- 로그인 폼 -->
          <form v-if="tab === 'login'" @submit.prevent="handleLogin" class="form">
            <div class="form-group">
              <label class="form-label">이메일</label>
              <input v-model="loginForm.email" type="email" class="form-input" placeholder="student@lecture.com" required />
            </div>
            <div class="form-group">
              <label class="form-label">비밀번호</label>
              <input v-model="loginForm.password" type="password" class="form-input" placeholder="••••••••" required />
            </div>
            <div v-if="error" class="error-msg">{{ error }}</div>
            <button type="submit" class="btn btn-primary btn-full" :disabled="loading">
              <span v-if="loading">로그인 중...</span>
              <span v-else>로그인</span>
            </button>
            <div class="divider"><span>또는</span></div>
            <button type="button" class="btn btn-ghost btn-full" @click="handleOAuth">
              OAuth2 로그인
            </button>
          </form>

          <!-- 회원가입 폼 -->
          <form v-else @submit.prevent="handleRegister" class="form">
            <div class="form-group">
              <label class="form-label">이름</label>
              <input v-model="registerForm.name" type="text" class="form-input" placeholder="홍길동" required />
            </div>
            <div class="form-group">
              <label class="form-label">이메일</label>
              <input v-model="registerForm.email" type="email" class="form-input" placeholder="user@example.com" required />
            </div>
            <div class="form-group">
              <label class="form-label">비밀번호</label>
              <input v-model="registerForm.password" type="password" class="form-input" placeholder="••••••••" required />
            </div>
            <div class="form-group">
              <label class="form-label">역할</label>
              <select v-model="registerForm.role" class="form-input">
                <option value="STUDENT">학생</option>
                <option value="INSTRUCTOR">강사</option>
              </select>
            </div>
            <div v-if="error" class="error-msg">{{ error }}</div>
            <button type="submit" class="btn btn-primary btn-full" :disabled="loading">
              <span v-if="loading">가입 중...</span>
              <span v-else>회원가입</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth.js'
import { authApi } from '@/api/auth.js'
import api from '@/api/index.js'

const router = useRouter()
const auth = useAuthStore()

const tab = ref('login')
const loading = ref(false)
const error = ref('')

const loginForm = ref({ email: '', password: '' })
const registerForm = ref({ name: '', email: '', password: '', role: 'STUDENT' })

const features = ['수강 중인 강의 이어보기', '맞춤 강의 추천', '수료증 관리']

async function handleLogin() {
  error.value = ''
  loading.value = true
  try {
    // 직접 로그인: auth-server의 /api/login 엔드포인트 호출
    const res = await api.post('/api/login', loginForm.value)
    auth.setToken(res.data.access_token)
    await auth.fetchUser()
    router.push('/courses')
  } catch (e) {
    error.value = e.response?.data?.message || '로그인에 실패했습니다.'
  } finally {
    loading.value = false
  }
}

async function handleRegister() {
  error.value = ''
  loading.value = true
  try {
    await authApi.register(registerForm.value)
    tab.value = 'login'
    loginForm.value.email = registerForm.value.email
    error.value = ''
    alert('회원가입이 완료되었습니다. 로그인해 주세요.')
  } catch (e) {
    error.value = e.response?.data?.message || '회원가입에 실패했습니다.'
  } finally {
    loading.value = false
  }
}

function handleOAuth() {
  auth.redirectToLogin()
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  background: var(--color-bg-secondary);
  display: flex;
  align-items: stretch;
}
.login-layout {
  display: grid;
  grid-template-columns: 1fr 1fr;
  width: 100%;
  min-height: 100vh;
}

/* 좌측 */
.login-left {
  background: linear-gradient(160deg, #1a4f8a 0%, #185FA5 50%, #1e7bc4 100%);
  padding: 48px;
  display: flex;
  flex-direction: column;
  gap: 48px;
}
.brand { display: flex; align-items: center; gap: 10px; }
.brand-logo { width: 40px; height: 40px; border-radius: 10px; object-fit: contain; }
.brand-name { font-size: 18px; font-weight: 700; color: #fff; }
.brand-content h2 {
  font-size: 32px;
  font-weight: 700;
  color: #fff;
  line-height: 1.35;
  margin-bottom: 14px;
}
.brand-content p { font-size: 15px; color: rgba(255,255,255,0.75); margin-bottom: 28px; }
.feature-list { list-style: none; display: flex; flex-direction: column; gap: 12px; }
.feature-list li {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 14px;
  color: rgba(255,255,255,0.85);
}
.dot { width: 7px; height: 7px; border-radius: 50%; background: rgba(255,255,255,0.6); flex-shrink: 0; }

/* 우측 */
.login-right {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  background: var(--color-bg-primary);
}
.login-box { width: 100%; max-width: 400px; }
.back-link {
  display: inline-block;
  font-size: 13px;
  color: var(--color-text-secondary);
  margin-bottom: 28px;
  transition: var(--transition);
}
.back-link:hover { color: var(--color-primary); }

/* 탭 */
.tabs {
  display: flex;
  gap: 0;
  background: var(--color-bg-tertiary);
  border-radius: var(--radius-md);
  padding: 4px;
  margin-bottom: 28px;
}
.tab {
  flex: 1;
  padding: 9px;
  border-radius: var(--radius-sm);
  font-size: 14px;
  font-weight: 500;
  color: var(--color-text-secondary);
  background: transparent;
  transition: var(--transition);
}
.tab.active {
  background: var(--color-bg-primary);
  color: var(--color-text-primary);
  box-shadow: var(--shadow-sm);
}

/* 폼 */
.form { display: flex; flex-direction: column; gap: 16px; }
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-label { font-size: 13px; font-weight: 500; color: var(--color-text-secondary); }
.form-input {
  padding: 10px 14px;
  border: 1.5px solid var(--color-border);
  border-radius: var(--radius-md);
  font-size: 14px;
  font-family: var(--font-sans);
  color: var(--color-text-primary);
  background: var(--color-bg-primary);
  transition: var(--transition);
  outline: none;
}
.form-input:focus { border-color: var(--color-primary); box-shadow: 0 0 0 3px var(--color-primary-light); }
.btn-full { width: 100%; padding: 12px; font-size: 15px; justify-content: center; }
.divider {
  display: flex;
  align-items: center;
  gap: 12px;
  color: var(--color-text-muted);
  font-size: 12px;
}
.divider::before,
.divider::after { content: ''; flex: 1; height: 1px; background: var(--color-border); }
.error-msg {
  padding: 10px 14px;
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: var(--radius-md);
  font-size: 13px;
  color: #dc2626;
}
</style>
