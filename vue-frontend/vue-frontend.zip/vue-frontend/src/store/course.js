import { defineStore } from 'pinia'
import { ref } from 'vue'
import { courseApi } from '@/api/course.js'

export const useCourseStore = defineStore('course', () => {
  const courses = ref([])
  const selectedCourse = ref(null)
  const loading = ref(false)
  const error = ref(null)
  const selectedCategory = ref('전체')

  const categories = ['전체', '백엔드', '프론트엔드', 'DevOps', '데이터', 'AI']

  // 썸네일 이미지 매핑
  const thumbnailMap = {
    'SPRING': new URL('@/assets/images/courses/spring_boot.png', import.meta.url).href,
    'VUE': new URL('@/assets/images/courses/vue_js.png', import.meta.url).href,
    'DOCKER': new URL('@/assets/images/courses/docker.png', import.meta.url).href,
    'KUBERNETES': new URL('@/assets/images/courses/kubernetes.png', import.meta.url).href,
    'PYTHON': new URL('@/assets/images/courses/python.png', import.meta.url).href,
    'AI': new URL('@/assets/images/courses/generative_ai.png', import.meta.url).href,
  }

  function getThumbnail(course) {
    const key = course.thumbnail?.toUpperCase() || ''
    return thumbnailMap[key] || null
  }

  async function fetchCourses() {
    loading.value = true
    error.value = null
    try {
      const res = await courseApi.getAll()
      courses.value = res.data
    } catch (e) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function fetchCourse(id) {
    loading.value = true
    try {
      const res = await courseApi.getById(id)
      selectedCourse.value = res.data
    } finally {
      loading.value = false
    }
  }

  function setCategory(cat) {
    selectedCategory.value = cat
  }

  return {
    courses,
    selectedCourse,
    loading,
    error,
    categories,
    selectedCategory,
    thumbnailMap,
    getThumbnail,
    fetchCourses,
    fetchCourse,
    setCategory
  }
})
