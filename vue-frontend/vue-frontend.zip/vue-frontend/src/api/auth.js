import api from './index.js'
import axios from 'axios'

export const authApi = {
  // OAuth2 Authorization Code → Access Token 교환
  exchangeCode(code) {
    return axios.post(
      `${import.meta.env.VITE_AUTH_SERVER_URL}/oauth2/token`,
      new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: import.meta.env.VITE_REDIRECT_URI,
        client_id: import.meta.env.VITE_CLIENT_ID
      }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
    )
  },

  // 내 정보 조회
  getMe() {
    return api.get('/api/users/me')
  },

  // 회원가입
  register(data) {
    return api.post('/api/users/register', data)
  }
}
